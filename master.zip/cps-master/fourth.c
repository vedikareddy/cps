#include<stdio.h>
int main()
{
char a,sum;
int b,c;
printf("enter the charecter");
scanf("%c",&a);
b=a;
c=b-31;
sum=c;
printf("%c",sum);
}



