/*#include<stdio.h>
int main()
{
int x=2,y=3;
printf("%d",x&y);
}*/
/*#include<stdio.h>
int main()
{char a[2][3]={'g','e','e','k','s'};
printf("%s",**a);
}*/
#include<stdio.h>
int main()
{
if(printf("hello world")){
}
}
