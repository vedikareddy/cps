#include<stdio.c>
int main()
{
int a[2];
a=a+1;
a+=1;
a++;
}
