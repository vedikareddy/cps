#include<stdio.h>
int main()
{
	printf("%s","vedika");
	return 0;
}
