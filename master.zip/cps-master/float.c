#include<stdio.h>
void main ()
{
float f=0.1f;
if(f==0.1f)
printf("true");
else
printf("false");
}
