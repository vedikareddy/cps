using namespace std;
#include<iostream>
int main()
{
int n1,n2,sum;
cout<< "enter n1\n";
cin>>n1;
cout<<"enter n2\n";
cin>>n2;
sum=n1+n2;
cout<<"sum is "<<sum<< std::endl;
return 0;
}

