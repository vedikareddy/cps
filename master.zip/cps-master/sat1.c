#include<stdio.h>
int main()
{
printf("%d\n",printf("%d\n","vedika"));
}
