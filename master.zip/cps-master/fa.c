#include<stdio.h>
int main()
{
int a[]={1,2,3,4,5};

int i;
for(i=0;i<=4;i++)
printf("%d",a[i]*a[i]);


}
