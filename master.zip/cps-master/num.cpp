#include<iostream>
using std::cout;
using std::cin;
using std::endl;
int x=1;
class num
{
public:num(){
	
	cout<<x<<endl;
	x++;
	}
};
int main()
{
num x[100];
return 0;
}


