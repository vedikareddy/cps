#include<stdio.h>
int main()
{
	
	int x='a';
	printf("%d",x);
}
