#include<stdio.h>
int main()
{
int a;
char b[20];
printf("enter any number");
scanf("%d",&a);
printf("enter your name");
scanf("%s",b);
if(a>7)
{
printf("hey %s your so cool and it is %d",b,a);
}
else
{
printf("better luck next time");
}
} 

