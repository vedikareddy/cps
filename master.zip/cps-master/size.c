#include<stdio.h>
int main()
{
int *p;
char *q;
float *r;
printf("%d\n",sizeof(p));
printf("%d\n",sizeof(q));
printf("%d\n",sizeof(r));
}
