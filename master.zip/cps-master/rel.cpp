using namespace std;
#include<iostream>
int main()
{
int n1,n2;
cout<<"enter the 2 numbers i will tell you something special\n";
cin>>n1>>n2;
if(n1==n2)
cout<<n1<<"is equal to"<<n2<<endl;
if(n1!=n2)
cout<<n1<<"is not equal to"<<n2<<endl;
if(n1<n2)
cout<<n1<<"is less to"<<n2<<endl;
if(n1>n2)
cout<<n1<<"is greater to"<<n2<<endl;
if(n1<=n2)
cout<<n1<<"is less than or  equal to"<<n2<<endl;
if(n1>=n2)
cout<<n1<<"is greater than or equal to"<<n2<<endl;
return 0;
}
