#include<stdio.h>
int main()
{
int a,b,i;
printf("enter the number");
scanf("%d",&a);
for(i=1;i<=10;i++)
{
b=a*i;
printf("%d\n",b);
}
}

