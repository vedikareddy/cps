#include<stdio.h>
int main()
{
        int cond = 1;
        if ( cond ) {
                printf("Condition is true...!\n");
        } else {
                printf("Condition is false...!\n");
                return(1);
        }
        printf("End of program\n");
        return(0);
}
