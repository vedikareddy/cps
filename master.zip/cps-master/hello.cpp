using namespace std;
#include<iostream>
int main()
{
cout<< " hello vedika how do you do ? ";
cout<< "welcome to c++ !!do well! \n";
return 0;
}
