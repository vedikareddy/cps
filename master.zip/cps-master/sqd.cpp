#include<iostream>
using namespace std;
class sq(){
public:sq()
{
construct()
{
cout<<a<<endl;
}

~cnd()
{
cout<<a*a<<endl;
}
}
};
int main()
{
sq a[10];
return 0;
}
