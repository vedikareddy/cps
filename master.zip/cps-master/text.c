#include<stdio.h>
int main()
{
int a,b;
int i,j;
}
