#include<stdio.h>
int main()
{
	printf("%s","hello world");
	return 0;
}
