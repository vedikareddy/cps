#include<stdio.h>
void main()
{
int x;
printf("enter the number");
scanf("%d",&x);
if(x%2==1||x%2==-1)
printf("odd");
else
printf("even");
}

