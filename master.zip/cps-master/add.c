#include<stdio.h>
int main()
{
	int a,b;
	printf("enter the numbers a and b");
	scanf("%d%d",&a,&b);
	printf("the sum of the two numbers is=%d\n",a+b);
	printf("difference two numbers is=%d\n",b-a);
	printf("product of two numbers is=%d\n",b*a);
	printf("quotient of two numbers is=%d\n",b/a);

}

