#include<stdio.h>
int main()
{
	printf("%s","vedika is a good girl");
	return 0;
}

